package com.ars.exception;

public class ARSException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3999459769801329354L;

	public ARSException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ARSException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
