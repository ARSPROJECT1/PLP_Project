package com.ars.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ars.bean.BookingInformationBean;
import com.ars.bean.FlightInformationBean;
import com.ars.exception.ARSException;
import com.ars.service.IArsService;

@Controller
public class ArsController {

	@Autowired
	IArsService arsService;

	public IArsService getArsService() {
		return arsService;
	}

	public void setArsService(IArsService arsService) {
		this.arsService = arsService;
	}

	@RequestMapping("/showHome")
	public String showHomePage()
	{
		return ("index");
	}
	
	@RequestMapping("/book")
	public String viewAll()
	{
		return ("viewAll");
	}
	
	@RequestMapping("/viewAllFlights")
	public ModelAndView viewAllFlights(@RequestParam("departureCity")String depCity,@RequestParam("arrivalCity")String arrCity)
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			List<FlightInformationBean> list=arsService.viewFlights(depCity, arrCity);
			mv.setViewName("viewAll");
			if (list!=null) {
				mv.addObject("list", list);
				mv.addObject("message", "Flight Details : ");
			} else {
				mv.addObject("message", "No Flights found!!!");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","viewAllFlights() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	
	@RequestMapping(value="/confirmBooking",method=RequestMethod.POST)
	public ModelAndView confirmBooking(@ModelAttribute("bookBean")BookingInformationBean bean)
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			BookingInformationBean bookedbean=arsService.confirmBooking(bean);
			mv.setViewName("success");
			if (bookedbean!=null) {
				mv.addObject("bean", bookedbean);
				mv.addObject("message", "Booked Sucessfully");
			} else {
				mv.addObject("message", "Booking Failed");
			}
			
		} catch (ARSException e) {
			mv.addObject("message","confirmBooking() exception "+e.getMessage());
			mv.setViewName("error");
			
		}
		
		return mv;
	}
	
	
	@RequestMapping(value="/displayBooking")
	public ModelAndView displayBooking(@RequestParam("bookingId")String bookingId)
	{
		ModelAndView mv = new ModelAndView();
		
		try {
			BookingInformationBean bean=arsService.displayBooking(bookingId);
			mv.setViewName("display");
			mv.addObject("bean", bean);
			
			
		} catch (ARSException e) {
			mv.addObject("message","displayBooking() exception "+e.getMessage());
			mv.setViewName("error");
		}
		
		return mv;
	}
	
	
	
}
