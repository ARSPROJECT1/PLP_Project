package com.cg.ars.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Airport")
public class AirportBean {
	
	@Id
	@Column(name="AirportName")
	private String airportName;
	@Column(name="Abbreviation")
	private String abbreviation;
	@Column(name="Location")
	private String location;
	
	public AirportBean() {
		super();
	}
	
	public AirportBean(String airportName, String abbreviation, String location) {
		super();
		this.airportName = airportName;
		this.abbreviation = abbreviation;
		this.location = location;
	}
	
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	public String getAbbreviation() {
		return abbreviation;
	}
	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	@Override
	public String toString() {
		return "AirportBean [airportName=" + airportName + ", abbreviation="
				+ abbreviation + ", location=" + location + "]";
	}
	
	

}