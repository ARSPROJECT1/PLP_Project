package com.cg.ars.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;

@Repository
@Transactional
public class ArsDaoImpl implements IArsDao {

	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public BookingInformationBean confirmBooking(
			BookingInformationBean bookingInformationBean,
			FlightInformationBean flightInformationBean) throws ARSException {
		BookingInformationBean bean=null;
		FlightInformationBean fbean=null;
		
		
		return bean;
	}

	@Override
	public BookingInformationBean displayBooking(String bookingId)
			throws ARSException {

		BookingInformationBean bean=null;
		try {
			bean = entityManager.find(BookingInformationBean.class, bookingId);
		} catch (Exception e) {
			throw new ARSException("Exception in displayBooking() in dao layer "+e.getMessage());
		}
		
		return bean;
	}

	@Override
	public BookingInformationBean cancelBooking(String bookingId)
			throws ARSException {
		BookingInformationBean bean= entityManager.find(BookingInformationBean.class, bookingId);
		FlightInformationBean fbean= entityManager.find(FlightInformationBean.class, bean.getFlightNumber());
		
		try {
			
			if(bean!=null)
			{	
				entityManager.remove(bean);
				if(bean.getClassType().equalsIgnoreCase("firstclass"))
				{	
					int firstClassSeats=bean.getNumberOfPassengers()+fbean.getFirstClassSeats();
					fbean.setFirstClassSeats(firstClassSeats);
				}
				else
				{
					int bussClassSeats=bean.getNumberOfPassengers()+fbean.getBussinessClassSeats();
					fbean.setFirstClassSeats(bussClassSeats);
				}
				entityManager.merge(fbean);
				entityManager.flush();
				
			}
		} catch (Exception e) {
			throw new ARSException("Exception in cancelBooking() in dao layer "+e.getMessage() );
		}
		return bean;
	}

	@Override
	public BookingInformationBean updateBooking(String bookingId,
			String cust_email) throws ARSException {
		try {
			BookingInformationBean bean = entityManager.find(BookingInformationBean.class, bookingId);
			if(bean!=null)
			{
				bean.setCustomerEmail(cust_email);
				entityManager.merge(bean);
				entityManager.flush();
				return bean;
			}
		} catch (Exception e) {
			throw new ARSException("Exception in updateBooking() in dao layer "+e.getMessage() );
		}
		return null;
	}

	@Override
	public List<FlightInformationBean> viewFlights(String Source,
			String destination) throws ARSException {
		List<FlightInformationBean> list =null;
		try {
			TypedQuery<FlightInformationBean> qry = entityManager.createQuery("from FlightInformation where dep_city=? and arr_city=?", FlightInformationBean.class);
			qry.setParameter(0, Source);
			qry.setParameter(1, destination);
			list = qry.getResultList();
		} catch (Exception e) {
			throw new ARSException("Exception in viewFlights() in dao layer "+e.getMessage() );
		}
		
		return list;
	}

}
