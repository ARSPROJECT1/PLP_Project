package com.cg.ars.dao;

import java.util.List;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;

public interface IArsDao {

	
	public BookingInformationBean confirmBooking(BookingInformationBean bookingInformationBean, FlightInformationBean flightInformationBean) throws ARSException;

	public BookingInformationBean displayBooking(String bookingId) throws ARSException;

	public BookingInformationBean cancelBooking(String bookingId) throws ARSException;
	
	public BookingInformationBean updateBooking(String bookingId,String cust_email) throws ARSException;

	public List<FlightInformationBean> viewFlights(String Source,String destination)throws ARSException;
	
	
}
